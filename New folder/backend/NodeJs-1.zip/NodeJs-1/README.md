# NodeJs-1

We have the basic code for CRUD operations on user, add two more schema `doctor` and `pharmacist`. Add a key `user_id` in both the schema and store the value of _id of user whom you want as a doctor or pharmacist in your system. This is creating DB for users, doctors and pharmacists.

Use of promises:- Make an api in which using promises you have to fetch all the users, then all the doctors, store the users mapped to the doctors in an array, similarly find all the pharmacist and store the corresponding users in a different array.


//http://blog.revathskumar.com/2015/07/using-promises-with-mongoosejs.html//